package Clen.dario

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
